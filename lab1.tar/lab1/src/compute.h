#ifndef COMPUTE_H
#define COMPUTE_H

uint64_t compute();

#endif // COMPUTE_H
