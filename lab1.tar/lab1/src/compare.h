#ifndef COMPARE_H
#define COMPARE_H

int compare();

#endif // COMPARE_H
